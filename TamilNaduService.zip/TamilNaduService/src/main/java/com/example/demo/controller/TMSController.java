package com.example.demo.controller;

import com.example.demo.DTO.TNSLRSProviderEntity;
import com.example.demo.DTO.TamilNaduServiceLrsProviderEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import com.example.demo.DTO.TMSResponceDTO;
import com.example.demo.DTO.TMSRequestDTO;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@RestController
public class TMSController {

    @GetMapping("/")
    public String geturt() {

        return "Vivek";
    }

    @GetMapping("/TNSOutput")
    public List generateTNService(@RequestHeader("districtCode") String districtCode,
                                  @RequestHeader("talukCode") String talukCode,
                                  @RequestHeader("villCode") String villCode,
                                  @RequestHeader("surveyNo") String surveyNo,
                                  @RequestHeader("subdivNo") String subdivNo,
                                  @RequestHeader("lgd") boolean lgd) throws Exception {

        // List<ESignResponse>  YardResponseByENList1 = ESService.findByYardName(YardName);
        List list =new ArrayList();

        TamilNaduServiceLrsProviderEntity TmsProviderEntity = new TamilNaduServiceLrsProviderEntity();

        HashMap<String, String> params = new HashMap<>();
       // params.put("districtCode", districtCode);
      //  params.put("talukCode", talukCode);
        params.put("villCode", villCode);
       // params.put("surveyNo", surveyNo);
       // params.put("subdivNo", subdivNo);


       // HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory ();
        RestTemplate restTemplate = new RestTemplate();

        //String resourceUrl = "http://localhost:8989/ccc";
       // ResponseEntity<String> response = restTemplate.getForEntity(resourceUrl , String.class);

        String resourceUrl = "http://localhost:8989/TNSProvider";
        ResponseEntity<TNSLRSProviderEntity> response = restTemplate.getForEntity(resourceUrl, TNSLRSProviderEntity.class);

        list.add(response);

        TMSResponceDTO TmsResEntity = new TMSResponceDTO();

        if(villCode.equals("642914")) {
            TmsResEntity.setOwnNum(101);
            TmsResEntity.setOwner("Jailalita");
            TmsResEntity.setRelation("Mother");
            list.add(TmsResEntity);
            return list;
        }else if (subdivNo.equals("1234")){
            TmsResEntity.setOwnNum(102);
            TmsResEntity.setOwner("PremSingh");
            TmsResEntity.setRelation("Father");
            list.add(TmsResEntity);
            return list;
        }else {
            return null;
        }
    }
}