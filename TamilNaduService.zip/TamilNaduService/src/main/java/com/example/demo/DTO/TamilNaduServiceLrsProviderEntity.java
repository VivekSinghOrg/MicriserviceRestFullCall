package com.example.demo.DTO;

public class TamilNaduServiceLrsProviderEntity {
    String districtCode ;
    String talukCode ;
    String villCode ;
    String surveyNo ;
    String subdivNo ;
    String osurveyNo ;
    String partInd ;
    String govtPriCode ;
    String govtPriTamil ;
    String govtPriEng ;
    String irrSource ;
    int taxRate ;
    int soilTypPri ;
    int soilTypSec ;
    int soilClass ;
    double taxHect ;
    double extHect ;
    double extAres ;
    double totTax ;
    int pattaNo ;
    String poramboke ;
    String remarks ;
    String remarks1 ;
    String form8No ;
    String form6No ;
    boolean assessed ;
    boolean cultivable ;
    String lcFlag ;
    String deptName ;

    public String getDistrictCode() {
        return districtCode;
    }

    public void setDistrictCode(String districtCode) {
        this.districtCode = districtCode;
    }

    public String getTalukCode() {
        return talukCode;
    }

    public void setTalukCode(String talukCode) {
        this.talukCode = talukCode;
    }

    public String getVillCode() {
        return villCode;
    }

    public void setVillCode(String villCode) {
        this.villCode = villCode;
    }

    public String getSurveyNo() {
        return surveyNo;
    }

    public void setSurveyNo(String surveyNo) {
        this.surveyNo = surveyNo;
    }

    public String getSubdivNo() {
        return subdivNo;
    }

    public void setSubdivNo(String subdivNo) {
        this.subdivNo = subdivNo;
    }

    public String getOsurveyNo() {
        return osurveyNo;
    }

    public void setOsurveyNo(String osurveyNo) {
        this.osurveyNo = osurveyNo;
    }

    public String getPartInd() {
        return partInd;
    }

    public void setPartInd(String partInd) {
        this.partInd = partInd;
    }

    public String getGovtPriCode() {
        return govtPriCode;
    }

    public void setGovtPriCode(String govtPriCode) {
        this.govtPriCode = govtPriCode;
    }

    public String getGovtPriTamil() {
        return govtPriTamil;
    }

    public void setGovtPriTamil(String govtPriTamil) {
        this.govtPriTamil = govtPriTamil;
    }

    public String getGovtPriEng() {
        return govtPriEng;
    }

    public void setGovtPriEng(String govtPriEng) {
        this.govtPriEng = govtPriEng;
    }

    public String getIrrSource() {
        return irrSource;
    }

    public void setIrrSource(String irrSource) {
        this.irrSource = irrSource;
    }

    public int getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(int taxRate) {
        this.taxRate = taxRate;
    }

    public int getSoilTypPri() {
        return soilTypPri;
    }

    public void setSoilTypPri(int soilTypPri) {
        this.soilTypPri = soilTypPri;
    }

    public int getSoilClass() {
        return soilClass;
    }

    public void setSoilClass(int soilClass) {
        this.soilClass = soilClass;
    }

    public int getSoilTypSec() {
        return soilTypSec;
    }

    public void setSoilTypSec(int soilTypSec) {
        this.soilTypSec = soilTypSec;
    }

    public double getTaxHect() {
        return taxHect;
    }

    public void setTaxHect(double taxHect) {
        this.taxHect = taxHect;
    }

    public double getExtHect() {
        return extHect;
    }

    public void setExtHect(double extHect) {
        this.extHect = extHect;
    }

    public double getExtAres() {
        return extAres;
    }

    public void setExtAres(double extAres) {
        this.extAres = extAres;
    }

    public double getTotTax() {
        return totTax;
    }

    public void setTotTax(double totTax) {
        this.totTax = totTax;
    }

    public int getPattaNo() {
        return pattaNo;
    }

    public String getPoramboke() {
        return poramboke;
    }

    public void setPoramboke(String poramboke) {
        this.poramboke = poramboke;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getRemarks1() {
        return remarks1;
    }

    public void setRemarks1(String remarks1) {
        this.remarks1 = remarks1;
    }

    public void setPattaNo(int pattaNo) {
        this.pattaNo = pattaNo;
    }

    public String getForm8No() {
        return form8No;
    }

    public void setForm8No(String form8No) {
        this.form8No = form8No;
    }

    public String getForm6No() {
        return form6No;
    }

    public boolean isAssessed() {
        return assessed;
    }

    public void setAssessed(boolean assessed) {
        this.assessed = assessed;
    }

    public void setForm6No(String form6No) {
        this.form6No = form6No;
    }

    public boolean isCultivable() {
        return cultivable;
    }

    public void setCultivable(boolean cultivable) {
        this.cultivable = cultivable;
    }

    public String getLcFlag() {
        return lcFlag;
    }

    public void setLcFlag(String lcFlag) {
        this.lcFlag = lcFlag;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }
}
