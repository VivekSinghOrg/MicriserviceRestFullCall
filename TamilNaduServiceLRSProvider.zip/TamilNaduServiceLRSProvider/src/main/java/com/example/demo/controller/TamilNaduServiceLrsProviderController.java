package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import com.example.demo.Entity.TamilNaduServiceLrsProviderEntity;
import java.util.Scanner;

@RestController
public class TamilNaduServiceLrsProviderController {

    @GetMapping("/ccc")
    public String geturt() {
        return "Vivek";
    }

    //@RequestHeader("districtCode") String districtCode,
   // @RequestHeader("talukCode") String talukCode,
   // @RequestHeader("villCode") String villCode,
   // @RequestHeader("surveyNo") String surveyNo,
    //@RequestHeader("subdivNo") String subdivNo

      @GetMapping("/TNSProvider")
    //@GetMapping("/villCode")
    public TamilNaduServiceLrsProviderEntity generateTNService( ) throws Exception {
        //@PathVariable("villCode") String villCode
        //@RequestHeader("villCode") String villCode
        // List<ESignResponse>  YardResponseByENList1 = ESService.findByYardName(YardName);

        TamilNaduServiceLrsProviderEntity TmsProviderEntity = new TamilNaduServiceLrsProviderEntity();

      //  if(villCode.equals("642914")) {
            TmsProviderEntity.setDistrictCode("592");
            TmsProviderEntity.setTalukCode("5877");
            TmsProviderEntity.setVillCode("642914");
            TmsProviderEntity.setSurveyNo("225");
            TmsProviderEntity.setOsurveyNo("225-4");
            TmsProviderEntity.setSubdivNo("4B");
            TmsProviderEntity.setGovtPriCode("2");
            TmsProviderEntity.setGovtPriTamil("Rameshwaram");
            TmsProviderEntity.setGovtPriEng("Rayathuvari");
         return TmsProviderEntity;
        //}else if (villCode.equals("1234")){
         //   TmsProviderEntity.setDistrictCode("592N");
         //   TmsProviderEntity.setTalukCode("5877M");
          //  TmsProviderEntity.setVillCode("642914Q");
         //   TmsProviderEntity.setSurveyNo("225G");
          //  TmsProviderEntity.setOsurveyNo("225-4C");
         //   TmsProviderEntity.setSubdivNo("4B");
         //   TmsProviderEntity.setGovtPriCode("2N");
          //  TmsProviderEntity.setGovtPriTamil("RameshwaramL");
          //  TmsProviderEntity.setGovtPriEng("RayathuvariK");
          //  return TmsProviderEntity;

       // }else {
         //   return null;
       // }
}
    }
